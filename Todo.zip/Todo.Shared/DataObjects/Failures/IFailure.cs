﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataObjects
{
    /// <summary>
    /// Interface for all failures
    /// </summary>
    public interface IFailure
    {
    }
}
