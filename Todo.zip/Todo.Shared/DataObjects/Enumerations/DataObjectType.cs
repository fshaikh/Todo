﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataObjects
{
    public enum DataObjectType
    {
        User = 1,
        Todo = 2
    }
}
