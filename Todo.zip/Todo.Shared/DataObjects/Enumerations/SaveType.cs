﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataObjects
{
    /// <summary>
    /// Represnts save types
    /// </summary>
    public enum SaveType
    {
        Insert =1,
        Update,
        Delete
    }
}
