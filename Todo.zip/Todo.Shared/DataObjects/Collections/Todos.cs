﻿using System;
using System.Collections.Generic;

namespace DataObjects
{
    /// <summary>
    /// Represents a collection of Todo.
    /// </summary>
    public class Todos:List<Todo>
    {
    }
}
